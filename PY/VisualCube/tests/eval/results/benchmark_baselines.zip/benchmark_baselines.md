====================================================================================================
BENCHMARK BASELINE COMPARISON
====================================================================================================

--- Environment: void ---

  Agent                     food_eaten         area_visited       spiral_quality           mean_speed
  --------------- -------------------- -------------------- -------------------- --------------------
  nnn3                 0.00 +/- 0.00      166.91 +/- 12.18       0.25 +/- 0.24      133.29 +/- 40.58
  nnn7                 0.00 +/- 0.00      149.57 +/- 9.18        0.67 +/- 0.20      138.39 +/- 24.55
  stochastic           0.00 +/- 0.00       57.32 +/- 6.94        0.08 +/- 0.11       61.16 +/- 22.75
  crw                  0.00 +/- 0.00      113.67 +/- 4.28        0.07 +/- 0.09      127.71 +/- 35.69
  levy                 0.00 +/- 0.00      110.36 +/- 6.77        0.07 +/- 0.09      123.72 +/- 44.58
  logspiral            0.00 +/- 0.00      131.06 +/- 2.78        0.33 +/- 0.42       88.84 +/- 16.07
  ars                  0.00 +/- 0.00      113.10 +/- 4.22        0.07 +/- 0.09      130.54 +/- 28.70

--- Environment: dense_band ---

  Agent                     food_eaten         area_visited       spiral_quality           mean_speed
  --------------- -------------------- -------------------- -------------------- --------------------
  nnn3               372.53 +/- 250.10    114.48 +/- 37.35       0.12 +/- 0.14      185.80 +/- 140.20
  nnn7               213.12 +/- 141.63    108.06 +/- 28.51       0.19 +/- 0.19      274.44 +/- 136.16
  stochastic          44.37 +/- 49.87      57.37 +/- 6.72        0.07 +/- 0.10       73.13 +/- 31.43
  crw                 87.69 +/- 70.54     114.08 +/- 4.02        0.06 +/- 0.08      145.03 +/- 45.83
  levy                87.28 +/- 76.51     111.29 +/- 6.67        0.06 +/- 0.08      155.72 +/- 60.38
  logspiral          105.84 +/- 46.07     133.09 +/- 2.49        0.60 +/- 0.16      204.19 +/- 24.06
  ars                119.59 +/- 53.16      83.12 +/- 16.99       0.19 +/- 0.17      110.55 +/- 42.70

--- Environment: dense_bands ---

  Agent                     food_eaten         area_visited       spiral_quality           mean_speed
  --------------- -------------------- -------------------- -------------------- --------------------
  nnn3               482.85 +/- 76.36      71.02 +/- 15.96       0.07 +/- 0.08       62.03 +/- 20.34
  nnn7               385.25 +/- 131.48     50.51 +/- 8.30        0.13 +/- 0.16       82.71 +/- 10.79
  stochastic          61.19 +/- 61.28      57.45 +/- 6.95        0.07 +/- 0.10       63.13 +/- 25.46
  crw                105.11 +/- 79.38     113.62 +/- 4.03        0.06 +/- 0.08      130.87 +/- 37.71
  levy               126.89 +/- 97.71     110.53 +/- 6.69        0.06 +/- 0.08      126.33 +/- 48.75
  logspiral          227.79 +/- 32.12     131.22 +/- 2.63        0.46 +/- 0.35       97.36 +/- 16.70
  ars                126.20 +/- 73.24      81.24 +/- 22.17       0.18 +/- 0.18       98.66 +/- 38.39

====================================================================================================
EFFECT SIZES - NNN3 vs baselines (Cohen's d)
====================================================================================================

  --- void ---
    vs ars         : food_eaten=+inf (very large), area_visited=+5.90 (very large), spiral_quality=+0.98 (large), mean_speed=+0.08 (negligible)
    vs crw         : food_eaten=+inf (very large), area_visited=+5.83 (very large), spiral_quality=+0.97 (large), mean_speed=+0.15 (negligible)
    vs levy        : food_eaten=+inf (very large), area_visited=+5.74 (very large), spiral_quality=+0.98 (large), mean_speed=+0.22 (small)
    vs logspiral   : food_eaten=+inf (very large), area_visited=+4.06 (very large), spiral_quality=-0.22 (small), mean_speed=+1.44 (very large)
    vs nnn7        : food_eaten=+inf (very large), area_visited=+1.61 (very large), spiral_quality=-1.90 (very large), mean_speed=-0.15 (negligible)
    vs stochastic  : food_eaten=+inf (very large), area_visited=+11.05 (very large), spiral_quality=+0.93 (large), mean_speed=+2.19 (very large)

  --- dense_band ---
    vs ars         : food_eaten=+1.40 (very large), area_visited=+1.08 (large), spiral_quality=-0.48 (small), mean_speed=+0.73 (medium)
    vs crw         : food_eaten=+1.55 (very large), area_visited=+0.01 (negligible), spiral_quality=+0.48 (small), mean_speed=+0.39 (small)
    vs levy        : food_eaten=+1.54 (very large), area_visited=+0.12 (negligible), spiral_quality=+0.51 (medium), mean_speed=+0.28 (small)
    vs logspiral   : food_eaten=+1.48 (very large), area_visited=-0.70 (medium), spiral_quality=-3.27 (very large), mean_speed=-0.18 (negligible)
    vs nnn7        : food_eaten=+0.78 (medium), area_visited=+0.19 (negligible), spiral_quality=-0.41 (small), mean_speed=-0.64 (medium)
    vs stochastic  : food_eaten=+1.82 (very large), area_visited=+2.13 (very large), spiral_quality=+0.38 (small), mean_speed=+1.11 (large)

  --- dense_bands ---
    vs ars         : food_eaten=+4.77 (very large), area_visited=-0.53 (medium), spiral_quality=-0.79 (medium), mean_speed=-1.19 (large)
    vs crw         : food_eaten=+4.85 (very large), area_visited=-3.66 (very large), spiral_quality=+0.12 (negligible), mean_speed=-2.27 (very large)
    vs levy        : food_eaten=+4.06 (very large), area_visited=-3.23 (very large), spiral_quality=+0.17 (negligible), mean_speed=-1.72 (very large)
    vs logspiral   : food_eaten=+4.35 (very large), area_visited=-5.26 (very large), spiral_quality=-1.52 (very large), mean_speed=-1.90 (very large)
    vs nnn7        : food_eaten=+0.91 (large), area_visited=+1.61 (very large), spiral_quality=-0.47 (small), mean_speed=-1.27 (very large)
    vs stochastic  : food_eaten=+6.09 (very large), area_visited=+1.10 (large), spiral_quality=+0.06 (negligible), mean_speed=-0.05 (negligible)

====================================================================================================
EFFECT SIZES - NNN7 vs baselines (Cohen's d)
====================================================================================================

  --- void ---
    vs ars         : food_eaten=+inf (very large), area_visited=+5.11 (very large), spiral_quality=+3.87 (very large), mean_speed=+0.29 (small)
    vs crw         : food_eaten=+inf (very large), area_visited=+5.01 (very large), spiral_quality=+3.84 (very large), mean_speed=+0.35 (small)
    vs levy        : food_eaten=+inf (very large), area_visited=+4.86 (very large), spiral_quality=+3.89 (very large), mean_speed=+0.41 (small)
    vs logspiral   : food_eaten=+inf (very large), area_visited=+2.73 (very large), spiral_quality=+1.04 (large), mean_speed=+2.39 (very large)
    vs nnn3        : food_eaten=+inf (very large), area_visited=-1.61 (very large), spiral_quality=+1.90 (very large), mean_speed=+0.15 (negligible)
    vs stochastic  : food_eaten=+inf (very large), area_visited=+11.34 (very large), spiral_quality=+3.70 (very large), mean_speed=+3.26 (very large)

  --- dense_band ---
    vs ars         : food_eaten=+0.87 (large), area_visited=+1.06 (large), spiral_quality=-0.03 (negligible), mean_speed=+1.62 (very large)
    vs crw         : food_eaten=+1.12 (large), area_visited=-0.30 (small), spiral_quality=+0.82 (large), mean_speed=+1.27 (very large)
    vs levy        : food_eaten=+1.11 (large), area_visited=-0.16 (negligible), spiral_quality=+0.85 (large), mean_speed=+1.13 (large)
    vs logspiral   : food_eaten=+1.02 (large), area_visited=-1.24 (very large), spiral_quality=-2.33 (very large), mean_speed=+0.72 (medium)
    vs nnn3        : food_eaten=-0.78 (medium), area_visited=-0.19 (negligible), spiral_quality=+0.41 (small), mean_speed=+0.64 (medium)
    vs stochastic  : food_eaten=+1.59 (very large), area_visited=+2.45 (very large), spiral_quality=+0.74 (medium), mean_speed=+2.04 (very large)

  --- dense_bands ---
    vs ars         : food_eaten=+2.43 (very large), area_visited=-1.84 (very large), spiral_quality=-0.30 (small), mean_speed=-0.57 (medium)
    vs crw         : food_eaten=+2.58 (very large), area_visited=-9.68 (very large), spiral_quality=+0.55 (medium), mean_speed=-1.74 (very large)
    vs levy        : food_eaten=+2.23 (very large), area_visited=-7.96 (very large), spiral_quality=+0.58 (medium), mean_speed=-1.24 (very large)
    vs logspiral   : food_eaten=+1.65 (very large), area_visited=-13.11 (very large), spiral_quality=-1.21 (very large), mean_speed=-1.04 (large)
    vs nnn3        : food_eaten=-0.91 (large), area_visited=-1.61 (very large), spiral_quality=+0.47 (small), mean_speed=+1.27 (very large)
    vs stochastic  : food_eaten=+3.16 (very large), area_visited=-0.91 (large), spiral_quality=+0.48 (small), mean_speed=+1.00 (large)

====================================================================================================
RANK ORDERING (best to worst per metric)
====================================================================================================

  --- void ---
    food_eaten          : ars(0.00) > crw(0.00) > levy(0.00) > logspiral(0.00) > nnn3(0.00) > nnn7(0.00) > stochastic(0.00)
    area_visited        : nnn3(166.91) > nnn7(149.57) > logspiral(131.06) > crw(113.67) > ars(113.10) > levy(110.36) > stochastic(57.32)
    spiral_quality      : nnn7(0.67) > logspiral(0.33) > nnn3(0.25) > stochastic(0.08) > crw(0.07) > levy(0.07) > ars(0.07)
    mean_speed          : nnn7(138.39) > nnn3(133.29) > ars(130.54) > crw(127.71) > levy(123.72) > logspiral(88.84) > stochastic(61.16)

  --- dense_band ---
    food_eaten          : nnn3(372.53) > nnn7(213.12) > ars(119.59) > logspiral(105.84) > crw(87.69) > levy(87.28) > stochastic(44.37)
    area_visited        : logspiral(133.09) > nnn3(114.48) > crw(114.08) > levy(111.29) > nnn7(108.06) > ars(83.12) > stochastic(57.37)
    spiral_quality      : logspiral(0.60) > ars(0.19) > nnn7(0.19) > nnn3(0.12) > stochastic(0.07) > crw(0.06) > levy(0.06)
    mean_speed          : nnn7(274.44) > logspiral(204.19) > nnn3(185.80) > levy(155.72) > crw(145.03) > ars(110.55) > stochastic(73.13)

  --- dense_bands ---
    food_eaten          : nnn3(482.85) > nnn7(385.25) > logspiral(227.79) > levy(126.89) > ars(126.20) > crw(105.11) > stochastic(61.19)
    area_visited        : logspiral(131.22) > crw(113.62) > levy(110.53) > ars(81.24) > nnn3(71.02) > stochastic(57.45) > nnn7(50.51)
    spiral_quality      : logspiral(0.46) > ars(0.18) > nnn7(0.13) > nnn3(0.07) > stochastic(0.07) > crw(0.06) > levy(0.06)
    mean_speed          : crw(130.87) > levy(126.33) > ars(98.66) > logspiral(97.36) > nnn7(82.71) > stochastic(63.13) > nnn3(62.03)

Report saved to tests\eval\results\benchmark_report.json
=== Step 4: Distribution report ===

====================================================================================================
DISTRIBUTION REPORT - Per-Trial Metric Statistics
====================================================================================================

  [bm_ars_ars_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1946    0.1618    0.1747    0.2801    0.73    0.0000    0.7635
  food_eaten              1000  119.5930  120.0000   53.1554   72.0000   -0.15    0.0000  268.0000
  area_cells_visited      1000   83.1170   83.0000   16.9864   21.0000   -0.27   27.0000  122.0000
  mean_speed              1000  110.5548  108.7613   42.7020   57.0302    0.96   48.6340  307.2772

  [bm_ars_ars_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1812    0.1286    0.1771    0.2461    1.14    0.0000    0.9023
  food_eaten              1000  126.2030  127.5000   73.2376  105.2500   -0.07    0.0000  311.0000
  area_cells_visited      1000   81.2400   82.0000   22.1722   34.2500   -0.12   24.0000  121.0000
  mean_speed              1000   98.6638   94.2831   38.3925   47.4836    0.95   48.1878  276.3397

  [bm_ars_ars_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0693    0.0353    0.0923    0.0983    1.94    0.0000    0.6060
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000  113.0970  113.0000    4.2154    5.0000   -0.71   92.0000  124.0000
  mean_speed              1000  130.5413  135.1455   28.7005   20.2069    1.39   60.0003  329.7094

  [bm_crw_crw_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0649    0.0328    0.0833    0.0901    1.84    0.0000    0.5087
  food_eaten              1000   87.6930   72.0000   70.5390   77.2500    1.66    0.0000  418.0000
  area_cells_visited      1000  114.0800  114.0000    4.0184    5.0000   -0.43   96.0000  129.0000
  mean_speed              1000  145.0282  135.7772   45.8273   55.1731    0.90   60.0970  344.4159

  [bm_crw_crw_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0623    0.0303    0.0842    0.0823    2.07    0.0000    0.5756
  food_eaten              1000  105.1070   94.0000   79.3794   99.0000    1.12    0.0000  516.0000
  area_cells_visited      1000  113.6220  114.0000    4.0293    5.0000   -0.30   93.0000  127.0000
  mean_speed              1000  130.8720  121.0278   37.7102   51.0770    0.92   60.0001  294.8434

  [bm_crw_crw_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0716    0.0383    0.0935    0.0956    1.96    0.0000    0.5905
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000  113.6710  114.0000    4.2794    5.0000   -0.27   94.0000  129.0000
  mean_speed              1000  127.7076  120.7409   35.6859   49.2777    0.87   60.0109  294.8870

  [bm_levy_levy_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0617    0.0281    0.0807    0.0870    2.01    0.0000    0.5261
  food_eaten              1000   87.2790   72.0000   76.5147   86.2500    1.54    0.0000  590.0000
  area_cells_visited      1000  111.2940  112.0000    6.6693    9.0000   -0.36   84.0000  130.0000
  mean_speed              1000  155.7235  142.9332   60.3769   70.6651    1.09   61.0241  531.6709

  [bm_levy_levy_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0593    0.0277    0.0765    0.0843    1.80    0.0000    0.4208
  food_eaten              1000  126.8890  111.5000   97.7083  122.0000    1.11    0.0000  576.0000
  area_cells_visited      1000  110.5250  111.0000    6.6869    9.0000   -0.49   83.0000  127.0000
  mean_speed              1000  126.3268  116.9465   48.7458   55.6628    1.37   60.9319  386.3742

  [bm_levy_levy_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0704    0.0367    0.0888    0.0974    2.03    0.0000    0.6989
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000  110.3650  111.0000    6.7695    9.0000   -0.52   83.0000  130.0000
  mean_speed              1000  123.7208  117.0612   44.5817   47.3018    1.25   61.1687  386.5376

  [bm_logspiral_log_spiral_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.5997    0.5740    0.1553    0.2425   -0.54    0.2069    0.8522
  food_eaten              1000  105.8400   91.5000   46.0749   55.0000    1.36   51.0000  252.0000
  area_cells_visited      1000  133.0850  133.0000    2.4872    4.0000   -0.23  125.0000  139.0000
  mean_speed              1000  204.1874  216.4879   24.0646   20.0700   -1.00  146.8739  256.6405

  [bm_logspiral_log_spiral_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.4610    0.6231    0.3520    0.6920   -0.40    0.0000    0.9708
  food_eaten              1000  227.7870  236.0000   32.1207   36.2500   -0.35  167.0000  301.0000
  area_cells_visited      1000  131.2200  131.0000    2.6345    3.0000   -0.18  123.0000  138.0000
  mean_speed              1000   97.3570   97.3457   16.6982   40.0515    0.00   77.3411  117.5803

  [bm_logspiral_log_spiral_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.3252    0.0000    0.4224    0.8346    0.54    0.0000    0.9631
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000  131.0630  131.0000    2.7822    4.0000   -0.10  123.0000  138.0000
  mean_speed              1000   88.8393   77.3417   16.0715   20.0589    0.92   77.3411  117.5358

  [bm_nnn3_composite_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1192    0.0728    0.1384    0.1520    1.71    0.0000    0.8076
  food_eaten              1000  372.5260  458.5000  250.1046  498.5000   -0.42    0.0000  758.0000
  area_cells_visited      1000  114.4780  100.0000   37.3506   63.0000    0.57   53.0000  199.0000
  mean_speed              1000  185.8038  122.0384  140.1998  182.3456    1.07   43.9321  565.9246

  [bm_nnn3_composite_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0724    0.0457    0.0790    0.0998    1.78    0.0000    0.6100
  food_eaten              1000  482.8520  494.0000   76.3602   85.2500   -1.26  113.0000  659.0000
  area_cells_visited      1000   71.0230   67.0000   15.9646   22.0000    1.15   44.0000  153.0000
  mean_speed              1000   62.0251   56.7240   20.3386   10.0286    3.53   42.0412  229.3816

  [bm_nnn3_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.2482    0.1666    0.2408    0.3499    0.96    0.0000    0.9588
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000  166.9110  168.0000   12.1838   16.0000   -0.52  121.0000  196.0000
  mean_speed              1000  133.2929  106.4701   40.5819   40.2518    1.49  106.4691  326.1876

  [bm_nnn7_composite_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1884    0.1110    0.1948    0.2679    1.15    0.0000    0.8595
  food_eaten              1000  213.1180  222.5000  141.6264  208.0000    0.07    0.0000  756.0000
  area_cells_visited      1000  108.0650  107.0000   28.5126   42.0000    0.29   53.0000  172.0000
  mean_speed              1000  274.4376  267.0191  136.1614  190.2354    0.63   68.3031  745.9529

  [bm_nnn7_composite_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1309    0.0630    0.1556    0.1768    1.48    0.0000    0.7196
  food_eaten              1000  385.2470  388.0000  131.4823  221.2500   -0.12   86.0000  687.0000
  area_cells_visited      1000   50.5050   50.0000    8.2992   11.0000    0.30   31.0000   81.0000
  mean_speed              1000   82.7069   81.7172   10.7948   16.5371    0.32   61.1881  112.2783

  [bm_nnn7_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.6684    0.7044    0.1987    0.2723   -0.83    0.0017    0.9837
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000  149.5750  150.0000    9.1791   12.0000   -0.19  117.0000  176.0000
  mean_speed              1000  138.3866  123.1427   24.5537   40.1596    1.45  123.1416  262.3235

  [bm_stochastic_stochastic_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0731    0.0212    0.1046    0.0998    1.84    0.0000    0.6062
  food_eaten              1000   44.3650   35.0000   49.8695   52.0000    2.49    0.0000  370.0000
  area_cells_visited      1000   57.3670   57.0000    6.7150    9.0000    0.04   38.0000   80.0000
  mean_speed              1000   73.1347   69.0542   31.4273   37.4741    0.99   20.4459  254.8317

  [bm_stochastic_stochastic_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0671    0.0029    0.1029    0.0979    1.90    0.0000    0.5077
  food_eaten              1000   61.1890   50.0000   61.2826   86.0000    1.41    0.0000  397.0000
  area_cells_visited      1000   57.4530   57.0000    6.9488    9.0000    0.08   34.0000   82.0000
  mean_speed              1000   63.1349   54.4519   25.4609   31.8762    0.96   22.1521  161.5428

  [bm_stochastic_stochastic_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0752    0.0093    0.1096    0.0999    1.82    0.0000    0.6177
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000   57.3200   57.0000    6.9403   10.0000    0.12   36.0000   81.0000
  mean_speed              1000   61.1619   53.7232   22.7543   23.1465    1.28   20.8123  195.1768