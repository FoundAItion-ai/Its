====================================================================================================
DISTRIBUTION REPORT - Per-Trial Metric Statistics
====================================================================================================

  [h5a1_composite_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.2221    0.2227    0.1186    0.1658    0.14    0.0000    0.6067
  food_eaten              1000  456.2960  474.0000  127.0362   96.2500   -1.88    0.0000  767.0000
  area_cells_visited      1000   48.9240   49.0000   10.9269   10.0000   -0.81   12.0000   83.0000
  mean_speed              1000  156.9728  156.2587   12.2274   10.2903    1.23  122.2749  197.9292

  [h5a2_composite_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1324    0.1153    0.1049    0.1700    0.65    0.0000    0.5087
  food_eaten              1000  559.5830  552.0000  112.2796  144.0000   -0.18  136.0000  801.0000
  area_cells_visited      1000   78.3450   78.0000   12.1089   17.0000    0.14   38.0000  121.0000
  mean_speed              1000  150.3026  151.4622   13.7302   19.7038   -0.10  119.4549  197.4428

  [h5a3_composite_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0583    0.0325    0.0693    0.0763    1.90    0.0000    0.5331
  food_eaten              1000  636.5390  630.5000  133.9707  177.2500    0.44  179.0000 1114.0000
  area_cells_visited      1000  128.3460  127.0000   16.4538   22.0000    0.40   84.0000  186.0000
  mean_speed              1000  147.6598  143.3795   28.5019   22.4111    5.19  101.3059  488.5729

  [h5a4_composite_dense_bands]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0750    0.0297    0.1092    0.0842    2.34    0.0000    0.6096
  food_eaten              1000  746.5790  744.0000  190.8208  281.5000   -0.17   37.0000 1205.0000
  area_cells_visited      1000  165.1760  158.0000   37.6160   49.0000    0.78   86.0000  305.0000
  mean_speed              1000  181.2233  141.6257   91.4031   81.8273    2.09   93.3805  646.4613

  Saved tests\eval\results\plots_h5\dist_spiral_quality.png
  Saved tests\eval\results\plots_h5\dist_food_eaten.png
  Saved tests\eval\results\plots_h5\dist_area_cells_visited.png
  Saved tests\eval\results\plots_h5\dist_mean_speed.png