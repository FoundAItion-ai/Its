====================================================================================================
DISTRIBUTION REPORT - Per-Trial Metric Statistics
====================================================================================================

  [h1a_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1650    0.0903    0.1867    0.2331    1.43    0.0000    0.9035
  area_cells_visited      1000  153.0070  154.0000   11.7961   17.0000   -0.26  112.0000  183.0000
  mean_speed              1000   79.1307   77.1547   11.1023    0.0003    7.06   77.1541  234.2948

  [h1b_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.2351    0.1556    0.2410    0.3349    1.04    0.0000    0.9664
  area_cells_visited      1000  169.3320  170.0000   10.0451   14.0000   -0.41  133.0000  194.0000
  mean_speed              1000   85.1542   78.3034   19.9883    0.0003    3.16   78.3028  213.0123

  [h1c_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.2899    0.2259    0.2538    0.3992    0.70    0.0000    0.9541
  area_cells_visited      1000  175.3370  176.0000    9.3948   13.0000   -0.68  136.0000  200.0000
  mean_speed              1000   88.3403   78.9523   22.9709    0.0003    3.22   78.9517  328.5737

  Saved tests\eval\results\plots_h1\dist_spiral_quality.png
  Saved tests\eval\results\plots_h1\dist_area_cells_visited.png
  Saved tests\eval\results\plots_h1\dist_mean_speed.png