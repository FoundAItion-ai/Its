====================================================================================================
DISTRIBUTION REPORT - Per-Trial Metric Statistics
====================================================================================================

  [h3a_composite_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0632    0.0322    0.0920    0.0779    3.32    0.0000    0.8778
  food_eaten              1000  283.9310  324.0000  131.0305  143.2500   -0.94    0.0000  529.0000
  area_cells_visited      1000   66.4640   68.0000   10.5267   11.0000   -0.36   25.0000  117.0000
  mean_speed              1000   59.9622   55.9961   14.2879   13.1661    3.34   43.3279  204.5987

  [h3b_composite_small_circle]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0921    0.0362    0.1423    0.0965    2.70    0.0000    0.9389
  food_eaten              1000  144.5630  180.0000  107.1748  217.2500   -0.15    0.0000  357.0000
  area_cells_visited      1000   69.1760   69.0000   14.1709   12.0000    0.84   20.0000  126.0000
  mean_speed              1000   67.6897   61.9123   16.6626   26.2229    3.30   45.2702  260.3886

  [h3c_inverter_dense_band]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0708    0.0213    0.1138    0.0880    2.59    0.0000    0.9049
  food_eaten              1000   88.1950  102.0000   50.3197   66.0000   -0.60    0.0000  187.0000
  area_cells_visited      1000  100.7760  104.0000   12.3862   14.0000   -1.13   53.0000  123.0000
  mean_speed              1000   99.0185   93.8467   39.3993   61.4466    1.94   56.6043  308.3184

  [h3d_inverter_small_circle]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0650    0.0244    0.1068    0.0716    3.11    0.0000    0.7766
  food_eaten              1000   48.2810   55.0000   35.6091   72.0000    0.13    0.0000  218.0000
  area_cells_visited      1000   98.1620  102.0000   13.0463   18.0000   -0.84   59.0000  121.0000
  mean_speed              1000   65.2544   62.1831   12.0258    6.6877    5.64   48.0818  166.3718

  Saved tests\eval\results\plots_h3\dist_spiral_quality.png
  Saved tests\eval\results\plots_h3\dist_food_eaten.png
  Saved tests\eval\results\plots_h3\dist_area_cells_visited.png
  Saved tests\eval\results\plots_h3\dist_mean_speed.png