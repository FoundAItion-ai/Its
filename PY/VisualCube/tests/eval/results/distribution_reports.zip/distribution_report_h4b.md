====================================================================================================
DISTRIBUTION REPORT - Per-Trial Metric Statistics
====================================================================================================

  [h4b1_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.2369    0.1450    0.2411    0.3614    0.96    0.0000    0.9397
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000  168.3410  170.0000   12.0653   16.0000   -0.45  124.0000  197.0000
  mean_speed              1000  133.2684  106.5132   40.0365   40.2542    1.57  106.5122  366.3576

  [h4b2_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1416    0.0699    0.1785    0.1956    1.71    0.0000    0.8855
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000  125.4970  128.0000   57.6105  115.0000   -0.12   26.0000  212.0000
  mean_speed              1000  143.9873  108.0078   58.8346   81.9374    1.27  102.7176  346.5854

  [h4b3_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.1049    0.0508    0.1388    0.1254    2.39    0.0000    0.9501
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000   80.1080   51.0000   61.1591   95.0000    0.86   11.0000  210.0000
  mean_speed              1000  123.8187  107.6237   43.6650    9.6622    2.58   99.3660  345.1814

  [h4b4_composite_void]
  Metric                     N      Mean    Median       Std       IQR    Skew       Min       Max
  ---------------------- ----- --------- --------- --------- --------- ------- --------- ---------
  spiral_quality          1000    0.0914    0.0443    0.1209    0.1224    2.36    0.0000    0.8360
  food_eaten              1000    0.0000    0.0000    0.0000    0.0000    0.00    0.0000    0.0000
  area_cells_visited      1000   57.2710   31.0000   56.9988   57.7500    1.40    7.0000  215.0000
  mean_speed              1000  118.9187  107.6774   38.5095   13.2014    3.43   96.7094  368.6344

  Saved tests\eval\results\plots_h4b\dist_spiral_quality.png
  Saved tests\eval\results\plots_h4b\dist_food_eaten.png
  Saved tests\eval\results\plots_h4b\dist_area_cells_visited.png
  Saved tests\eval\results\plots_h4b\dist_mean_speed.png