================================================================================                                        
Metrics (50 trials across 1 run)
================================================================================
  Config                         mean_speed sp_quality sp_growth_rate   cf_score straightness area_visited
  ------------------------------ ---------- ---------- ---------- ---------- ---------- ----------
  h1a_composite_void                76.1598     0.4182     0.0580     0.6921     0.1299    83.3400
  h1b_composite_void                79.4495     0.5251     0.1027     0.7005     0.1330    85.8600
  h1c_composite_void                77.8424     0.6015     0.1042     0.7077     0.1392    86.8600

================================================================================
Validation: H1 (50 trials across 1 run)
================================================================================
  [PASS] H1a spiral_quality > 0.15: 0.4182 > 0.1500
  [PASS] H1a growth_rate > 0: 0.0580 > 0.0000
  [PASS] H1a straightness < 0.3: 0.1299 < 0.3000
  [PASS] H1b spiral >= H1a: 0.5251 + 0.3231 >= 0.4182
  [PASS] H1b area >= H1a: 85.8600 > 82.3400
  [PASS] H1c spiral >= H1b: 0.6015 + 0.2779 >= 0.5251
  [PASS] H1c area >= H1b: 86.8600 > 84.8600
  [PASS] Spiral monotonicity: H1a <= H1b <= H1c: 0.4182(H1a) <= 0.5251(H1b) <= 0.6015(H1c)
  [PASS] Area monotonicity: H1a <= H1b <= H1c: 83.3400(H1a) <= 85.8600(H1b) <= 86.8600(H1c)

  9/9 checks passed

  >>> H1 PASSED <<<
