==========================================================================================
THRESHOLD SENSITIVITY ANALYSIS
==========================================================================================

--- H0 ---

  circle_fit_score thresholds:
  Check                                      Value   0.1   0.2   0.3   0.4   0.5
  ---------------------------------------- ------- ----- ----- ----- ----- -----
  H0b circle_fit > T                        0.6409     +     +     +     +     +
                                           5/5 pass, stable [0.1, 0.5]
  H0c circle_fit > T                        0.6419     +     +     +     +     +
                                           5/5 pass, stable [0.1, 0.5]
  H0f circle_fit > T                        0.6374     +     +     +     +     +
                                           5/5 pass, stable [0.1, 0.5]
  H0g circle_fit > T                        0.6348     +     +     +     +     +
                                           5/5 pass, stable [0.1, 0.5]

--- H1 ---

  spiral_quality thresholds:
  Check                                      Value  0.05  0.08   0.1  0.12  0.15  0.18   0.2  0.25   0.3  0.35
  ---------------------------------------- ------- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
  H1a spiral_quality > T                    0.1650     +     +     +     +     +     -     -     -     -     -
                                           5/10 pass, stable [0.05, 0.15]

--- H2 ---

  spiral_quality thresholds:
  Check                                      Value  0.05  0.08   0.1  0.12  0.15  0.18   0.2  0.25   0.3  0.35
  ---------------------------------------- ------- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
  H2a stochastic < T                        0.0384     +     +     +     +     +     +     +     +     +     +
                                           10/10 pass, stable [0.05, 0.35]
  H2b inverter < T                          0.0672     -     +     +     +     +     +     +     +     +     +
                                           9/10 pass, stable [0.08, 0.35]
  H2c composite (no cross) < T              0.1271     -     -     -     -     +     +     +     +     +     +
                                           6/10 pass, stable [0.15, 0.35]
  H2d composite (no stagger) < T            0.0597     -     +     +     +     +     +     +     +     +     +
                                           9/10 pass, stable [0.08, 0.35]
  H2e opposition only < T                   0.0730     -     +     +     +     +     +     +     +     +     +
                                           9/10 pass, stable [0.08, 0.35]
  H2f staggering only < T                   0.0881     -     -     +     +     +     +     +     +     +     +
                                           8/10 pass, stable [0.1, 0.35]
  H2g both > T                              0.3947     +     +     +     +     +     +     +     +     +     +
                                           10/10 pass, stable [0.05, 0.35]

--- H4B ---

  spiral_quality thresholds:
  Check                                      Value  0.05  0.08   0.1  0.12  0.15  0.18   0.2  0.25   0.3  0.35
  ---------------------------------------- ------- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
  H4b1 baseline > T                         0.2369     +     +     +     +     +     +     +     -     -     -
                                           7/10 pass, stable [0.05, 0.2]

--- H7 ---

  spiral_quality thresholds:
  Check                                      Value  0.05  0.08   0.1  0.12  0.15  0.18   0.2  0.25   0.3  0.35
  ---------------------------------------- ------- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
  H7a1 D_ROT=0 > T                          0.6521     +     +     +     +     +     +     +     +     +     +
                                           10/10 pass, stable [0.05, 0.35]
  H7a4 D_ROT=0.1 > T                        0.3058     +     +     +     +     +     +     +     +     +     -
                                           9/10 pass, stable [0.05, 0.3]
  H7a6 D_ROT=0.5 > T                        0.2380     +     +     +     +     +     +     +     -     -     -
                                           7/10 pass, stable [0.05, 0.2]

--- H8 ---

  spiral_quality thresholds:
  Check                                      Value  0.05  0.08   0.1  0.12  0.15  0.18   0.2  0.25   0.3  0.35
  ---------------------------------------- ------- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
  H8a1 3-inv > T                            0.2703     +     +     +     +     +     +     +     +     -     -
                                           8/10 pass, stable [0.05, 0.25]
  H8a5 7-inv > T                            0.7196     +     +     +     +     +     +     +     +     +     +
                                           10/10 pass, stable [0.05, 0.35]

--- H9 ---

  spiral_quality thresholds:
  Check                                      Value  0.05  0.08   0.1  0.12  0.15  0.18   0.2  0.25   0.3  0.35
  ---------------------------------------- ------- ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
  NEG-H1 stochastic < T                     0.0654     -     +     +     +     +     +     +     +     +     +
                                           9/10 pass, stable [0.08, 0.35]
  NEG-H2 same-C1 < T                        0.1069     -     -     -     +     +     +     +     +     +     +
                                           7/10 pass, stable [0.12, 0.35]
  NEG-H4a all-normal < T                    0.0961     -     -     +     +     +     +     +     +     +     +
                                           8/10 pass, stable [0.1, 0.35]

==========================================================================================
SUMMARY
==========================================================================================
  PARTIAL: h1 / H1a spiral_quality > T: 5/10 thresholds pass
  PARTIAL: h2 / H2b inverter < T: 9/10 thresholds pass
  PARTIAL: h2 / H2c composite (no cross) < T: 6/10 thresholds pass
  PARTIAL: h2 / H2d composite (no stagger) < T: 9/10 thresholds pass
  PARTIAL: h2 / H2e opposition only < T: 9/10 thresholds pass
  PARTIAL: h2 / H2f staggering only < T: 8/10 thresholds pass
  PARTIAL: h4b / H4b1 baseline > T: 7/10 thresholds pass
  PARTIAL: h7 / H7a4 D_ROT=0.1 > T: 9/10 thresholds pass
  PARTIAL: h7 / H7a6 D_ROT=0.5 > T: 7/10 thresholds pass
  PARTIAL: h8 / H8a1 3-inv > T: 8/10 thresholds pass
  PARTIAL: h9 / NEG-H1 stochastic < T: 9/10 thresholds pass
  PARTIAL: h9 / NEG-H2 same-C1 < T: 7/10 thresholds pass
  PARTIAL: h9 / NEG-H4a all-normal < T: 8/10 thresholds pass

Report saved to tests\eval\results\sensitivity_report.json